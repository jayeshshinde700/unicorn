-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: unicorn_hospitality
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_activity`
--

DROP TABLE IF EXISTS `admin_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_activity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `t` int(10) unsigned NOT NULL,
  `username` varchar(40) NOT NULL,
  `action` varchar(40) NOT NULL,
  `detail` varchar(200) NOT NULL DEFAULT '',
  `ip` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_t` (`t`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_activity`
--

LOCK TABLES `admin_activity` WRITE;
/*!40000 ALTER TABLE `admin_activity` DISABLE KEYS */;
INSERT INTO `admin_activity` VALUES (1,1793017913,'naman','setup','Admin account created','127.0.0.1');
INSERT INTO `admin_activity` VALUES (2,1793017963,'naman','room-unpublished','Deluxe Room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (3,1793017965,'naman','room-published','Deluxe Room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (4,1793017966,'naman','room-unpublished','Deluxe Room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (5,1793017967,'naman','room-published','Deluxe Room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (6,1793017970,'naman','room-unpublished','Premium Suite','127.0.0.1');
INSERT INTO `admin_activity` VALUES (7,1793017971,'naman','room-published','Premium Suite','127.0.0.1');
INSERT INTO `admin_activity` VALUES (8,1793017971,'naman','room-unpublished','Premium Suite','127.0.0.1');
INSERT INTO `admin_activity` VALUES (9,1793017973,'naman','room-published','Premium Suite','127.0.0.1');
INSERT INTO `admin_activity` VALUES (10,1793017978,'naman','room-unpublished','Deluxe Room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (11,1793017978,'naman','room-unpublished','Executive Room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (12,1793017979,'naman','room-unpublished','Family Suite','127.0.0.1');
INSERT INTO `admin_activity` VALUES (13,1793017979,'naman','room-unpublished','Premium Suite','127.0.0.1');
INSERT INTO `admin_activity` VALUES (14,1793017988,'naman','room-unpublished','The Unicon Suite','127.0.0.1');
INSERT INTO `admin_activity` VALUES (15,1793018004,'naman','room-published','Executive Room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (16,1793018005,'naman','room-published','Deluxe Room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (17,1793018005,'naman','room-published','Family Suite','127.0.0.1');
INSERT INTO `admin_activity` VALUES (18,1793018007,'naman','room-published','Premium Suite','127.0.0.1');
INSERT INTO `admin_activity` VALUES (19,1793018008,'naman','room-published','The Unicon Suite','127.0.0.1');
INSERT INTO `admin_activity` VALUES (20,1793018285,'naman','room-updated','Deluxe Room (published)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (21,1793078009,'naman','login','Signed in','127.0.0.1');
INSERT INTO `admin_activity` VALUES (23,1793249565,'naman','login','Signed in','127.0.0.1');
INSERT INTO `admin_activity` VALUES (24,1793249628,'naman','room-updated','Deluxe Room (published)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (25,1793249869,'naman','room-updated','Deluxe Room (published)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (26,1793250095,'naman','room-updated','Deluxe Room (published)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (27,1793250155,'naman','room-updated','Deluxe Room (published)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (28,1793250300,'naman','room-updated','delux bla (published)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (29,1793252842,'naman','login','Signed in','127.0.0.1');
INSERT INTO `admin_activity` VALUES (30,1793252849,'naman','room-unpublished','delux bla','127.0.0.1');
INSERT INTO `admin_activity` VALUES (31,1793252850,'naman','room-published','delux bla','127.0.0.1');
INSERT INTO `admin_activity` VALUES (32,1793252852,'naman','room-unpublished','delux bla','127.0.0.1');
INSERT INTO `admin_activity` VALUES (33,1793252968,'naman','room-updated','delux bla (draft)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (34,1793253147,'naman','room-updated','delux room (draft)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (35,1793253189,'naman','room-updated','delux room (draft)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (36,1793253489,'naman','room-updated','delux room (draft)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (37,1793253514,'naman','room-updated','delux room (draft)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (38,1793253578,'naman','room-created','new (draft)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (39,1793253598,'naman','room-published','delux room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (40,1793253628,'naman','room-updated','new (draft)','127.0.0.1');
INSERT INTO `admin_activity` VALUES (41,1793253636,'naman','room-published','new','127.0.0.1');
INSERT INTO `admin_activity` VALUES (42,1793253649,'naman','room-deleted','new','127.0.0.1');
INSERT INTO `admin_activity` VALUES (43,1793253803,'naman','room-unpublished','Executive Room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (44,1793256462,'naman','login','Signed in','127.0.0.1');
INSERT INTO `admin_activity` VALUES (45,1793256467,'naman','room-published','Executive Room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (46,1793256469,'naman','room-unpublished','delux room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (47,1793256470,'naman','room-published','delux room','127.0.0.1');
INSERT INTO `admin_activity` VALUES (48,1793366388,'naman','login','Signed in','127.0.0.1');
INSERT INTO `admin_activity` VALUES (49,1793422264,'naman','login','Signed in','127.0.0.1');
INSERT INTO `admin_activity` VALUES (50,1793447276,'naman','login','Signed in','127.0.0.1');
INSERT INTO `admin_activity` VALUES (51,1793450044,'naman','login','Signed in','127.0.0.1');
INSERT INTO `admin_activity` VALUES (52,1793451361,'system','coupon-created','DIWALI15','127.0.0.1');
INSERT INTO `admin_activity` VALUES (53,1793452021,'system','coupon-created','UITEST15','127.0.0.1');
INSERT INTO `admin_activity` VALUES (54,1793452023,'naman','login','Signed in','127.0.0.1');
INSERT INTO `admin_activity` VALUES (57,1793595272,'naman','login','Signed in','127.0.0.1');
INSERT INTO `admin_activity` VALUES (58,1793598269,'naman','coupon-created','STAYAH9U','127.0.0.1');
INSERT INTO `admin_activity` VALUES (59,1793860144,'naman','login','Signed in','::1');
/*!40000 ALTER TABLE `admin_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_attempts`
--

DROP TABLE IF EXISTS `admin_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_attempts` (
  `k` char(64) NOT NULL,
  `cnt` int(10) unsigned NOT NULL DEFAULT 0,
  `first_at` int(10) unsigned NOT NULL DEFAULT 0,
  `locked_until` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_attempts`
--

LOCK TABLES `admin_attempts` WRITE;
/*!40000 ALTER TABLE `admin_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `username` varchar(30) NOT NULL,
  `name` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES ('naman','naman','$2y$10$.zieaCFZ3S95wB1MWRfWAOnoW2gyzBXwfSBtnvsLIDi9Pb5hVV//6',1793017913);
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_events`
--

DROP TABLE IF EXISTS `booking_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `actor` varchar(60) NOT NULL,
  `event` varchar(30) NOT NULL,
  `detail` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_booking` (`booking_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_events`
--

LOCK TABLES `booking_events` WRITE;
/*!40000 ALTER TABLE `booking_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_rate_limits`
--

DROP TABLE IF EXISTS `booking_rate_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_rate_limits` (
  `bucket` char(64) NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT 0,
  `window_start` int(10) unsigned NOT NULL,
  PRIMARY KEY (`bucket`),
  KEY `idx_window` (`window_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_rate_limits`
--

LOCK TABLES `booking_rate_limits` WRITE;
/*!40000 ALTER TABLE `booking_rate_limits` DISABLE KEYS */;
INSERT INTO `booking_rate_limits` VALUES ('1817b488d7967fc308ad4650f0885ea19a519404eae40443c44187882ab2187c',2,1793451694);
INSERT INTO `booking_rate_limits` VALUES ('3d89d0c5bdae959746836d44b94e0f1cb86fcd4edf01919d73c7f3cdf592f067',1,1793861508);
INSERT INTO `booking_rate_limits` VALUES ('54668c924cde727483da3ccffaf48fd50d0f207147790324fcaedd398a426d94',1,1793366083);
INSERT INTO `booking_rate_limits` VALUES ('7770a682c5c8b200a52f5f5fa71de6b17e583aa4e3dfdb1cc3cbb04396743a7d',1,1793453125);
INSERT INTO `booking_rate_limits` VALUES ('9275fcea0b9f8ff22c21cbc63b74cc7839782c11e596bb1740c8cf47a449186e',1,1793598348);
INSERT INTO `booking_rate_limits` VALUES ('9fc3209c9aceafe86946ef8d909ca9cdbce39747830089a271af6b8be18a7515',1,1793861506);
INSERT INTO `booking_rate_limits` VALUES ('a561f345449edabf6a3dabf3c69c58a328b2aa50b7e604c96588497a78d07b10',1,1793366083);
INSERT INTO `booking_rate_limits` VALUES ('ac9301fd773c4deee1d21e09cac1fd1ddcbd8208caefad8bb4d1794947f14e12',1,1793453174);
INSERT INTO `booking_rate_limits` VALUES ('cf7a1a8da31fca369dd1621c026b87d06a09fb48e691dbdc5891555c1b257cc9',2,1793453125);
INSERT INTO `booking_rate_limits` VALUES ('ee4ce685247267dfb2145cb24ec0ec08cb2543dc6a1cc21d5460101cd035d6c6',1,1793598322);
/*!40000 ALTER TABLE `booking_rate_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` varchar(20) NOT NULL,
  `request_token` char(32) DEFAULT NULL,
  `room_id` varchar(40) NOT NULL,
  `room_name` varchar(60) NOT NULL,
  `guest_first_name` varchar(60) NOT NULL,
  `guest_last_name` varchar(60) NOT NULL,
  `email` varchar(190) NOT NULL,
  `phone_country` varchar(8) NOT NULL DEFAULT '+91',
  `phone` varchar(20) NOT NULL,
  `check_in` date NOT NULL,
  `check_out` date NOT NULL,
  `adults` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `children` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `number_of_nights` smallint(5) unsigned NOT NULL,
  `price_per_night` decimal(10,2) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL,
  `tax_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(12,2) NOT NULL,
  `special_requests` text DEFAULT NULL,
  `booking_status` enum('pending','confirmed','cancelled') NOT NULL DEFAULT 'confirmed',
  `hold_expires_at` datetime DEFAULT NULL,
  `email_status` varchar(12) NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancel_reason` varchar(30) DEFAULT NULL,
  `coupon_code` varchar(40) DEFAULT NULL,
  `discount_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_status` varchar(16) NOT NULL DEFAULT 'unpaid',
  `payment_method` varchar(12) DEFAULT NULL,
  `razorpay_order_id` varchar(40) DEFAULT NULL,
  `razorpay_payment_id` varchar(40) DEFAULT NULL,
  `paid_amount` decimal(12,2) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `refund_id` varchar(40) DEFAULT NULL,
  `refunded_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `refunded_at` datetime DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_booking_id` (`booking_id`),
  UNIQUE KEY `uq_request_token` (`request_token`),
  KEY `idx_email` (`email`),
  KEY `idx_room_dates` (`room_id`,`check_in`,`check_out`),
  KEY `idx_status` (`booking_status`),
  CONSTRAINT `fk_bookings_room` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (5,'UCH-H2TNTBNP','06ceb5eb2aae68f63020291a3c8c6070','executive','Executive Room','Aarav','Mehta','aarav.mehta@example.com','+91','9876543210','2026-10-30','2026-10-31',2,0,1,5800.00,5800.00,0.00,0.00,5800.00,'Quiet room, high floor','confirmed',NULL,'failed','2026-10-30 18:41:23','2026-10-30 18:41:23',NULL,NULL,NULL,0.00,'unpaid',NULL,NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL);
INSERT INTO `bookings` VALUES (8,'UCH-LBV37MY8','7fb85951d298b1d11470419017e55ee0','family','Family Suite','namass','sd','nmmana@gmail.com','+91','7208202849','2026-10-31','2026-11-01',2,2,1,8200.00,8200.00,0.00,0.00,8200.00,NULL,'confirmed',NULL,'failed','2026-10-31 17:49:11','2026-10-31 17:49:11',NULL,NULL,NULL,0.00,'unpaid',NULL,NULL,NULL,NULL,NULL,NULL,0.00,NULL,NULL);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(40) NOT NULL,
  `title` varchar(120) NOT NULL,
  `description` varchar(400) NOT NULL DEFAULT '',
  `discount_type` enum('percent','flat') NOT NULL DEFAULT 'percent',
  `discount_value` decimal(10,2) NOT NULL,
  `max_discount` decimal(10,2) DEFAULT NULL,
  `min_subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `min_nights` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `applies_to` varchar(10) NOT NULL DEFAULT 'all',
  `valid_from` date DEFAULT NULL,
  `valid_to` date DEFAULT NULL,
  `stay_from` date DEFAULT NULL,
  `stay_to` date DEFAULT NULL,
  `usage_limit` int(10) unsigned DEFAULT NULL,
  `per_email_limit` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES (4,'STAYAH9U','diwali','celebrate it','percent',10.00,NULL,0.00,1,'all','2026-11-01','2026-11-11','2026-11-01','2026-11-05',1,1,1,1,'2026-11-02 11:14:28','2026-11-02 11:14:28');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enquiries`
--

DROP TABLE IF EXISTS `enquiries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enquiries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `enquiry_type` varchar(20) NOT NULL,
  `check_in` date DEFAULT NULL,
  `check_out` date DEFAULT NULL,
  `guests` smallint(5) unsigned DEFAULT NULL,
  `message` text NOT NULL,
  `ip_hash` char(64) NOT NULL,
  `content_hash` char(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`),
  KEY `ip_hash` (`ip_hash`,`created_at`),
  KEY `content_hash` (`content_hash`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enquiries`
--

LOCK TABLES `enquiries` WRITE;
/*!40000 ALTER TABLE `enquiries` DISABLE KEYS */;
INSERT INTO `enquiries` VALUES (4,'2026-11-02 12:24:07','Test Contact','test@example.com','+91 9999999999','weddings','2027-01-01',NULL,150,'WEDDING ENQUIRY (weddings.html)\nCouple: Test A & Test B\nEvent type: Wedding & Reception\nEstimated guests: 150\nRooms required: 10\nAdditional requirements: Automated test enquiry - please ignore.','eff8e7ca506627fe15dda5e0e512fcaad70b6d520f37cc76597fdb4f2d83a1a3','694c0256ce6076604f4170cbf938365f280858ae6e9f4779faad2b7beeb82846');
/*!40000 ALTER TABLE `enquiries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rooms` (
  `id` varchar(40) NOT NULL,
  `name` varchar(60) NOT NULL,
  `category` enum('room','suite') NOT NULL DEFAULT 'room',
  `status` enum('published','draft') NOT NULL DEFAULT 'draft',
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `price` int(10) unsigned NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `guests` tinyint(3) unsigned NOT NULL,
  `rank_no` int(11) NOT NULL DEFAULT 0,
  `data` longtext NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  `updated_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status_rank` (`status`,`rank_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES ('deluxe','delux room','room','published',0,4500,32,2,1,'{\"id\":\"deluxe\",\"name\":\"delux room\",\"category\":\"room\",\"tags\":[\"family\"],\"badge\":{\"text\":\"Most booked\",\"style\":\"gold\"},\"status\":\"published\",\"featured\":false,\"short\":\"Calm neutrals\",\"tagline\":\"Calm, classic comfort\",\"description\":\"A quiet, softly lit room in warm neutrals. The king bed has plush bedding, quality linens and a choice of pillows, and tall windows with floor-length drapes let the morning in. Simple, restful and easy to love.\",\"notes\":\"Check-in from 2:00 PM, check-out by 11:00 AM. Extra bed on request, subject to availability. Breakfast, Wi-Fi, parking and pool access are included.\",\"size\":32,\"guests\":2,\"bed\":\"King bed\",\"view\":\"City light\",\"inventory\":12,\"extraBed\":{\"available\":false,\"price\":0},\"price\":4500,\"seasonal\":{\"festive\":null,\"winter\":null,\"summer\":null,\"monsoon\":null},\"image\":\"assets/images/unicon/rooms/deluxe.jpg\",\"imageAlt\":\"Deluxe Room at Unicorn Hospitality\",\"gallery\":[],\"amenities\":[{\"icon\":\"wifi\",\"label\":\"Free Wi-Fi\"},{\"icon\":\"snow\",\"label\":\"Air-conditioning\"},{\"icon\":\"tv\",\"label\":\"Flat-screen TV\"},{\"icon\":\"cup\",\"label\":\"Tea & coffee maker\"},{\"icon\":\"lock\",\"label\":\"In-room safe\"},{\"icon\":\"bed\",\"label\":\"Choice of pillows\"},{\"icon\":\"bath\",\"label\":\"En-suite bathroom\"},{\"icon\":\"car\",\"label\":\"Free parking\"}],\"features\":{\"desk\":false,\"shower\":false,\"lounge\":false,\"dining\":false,\"apart\":false},\"seoTitle\":\"\",\"seoDescription\":\"\",\"rank\":1,\"createdAt\":1793017963,\"updatedAt\":1793256470,\"updatedBy\":\"naman\"}',1793017963,1793256470);
INSERT INTO `rooms` VALUES ('executive','Executive Room','room','published',0,5800,38,2,2,'{\"id\":\"executive\",\"name\":\"Executive Room\",\"category\":\"room\",\"tags\":[],\"badge\":{\"text\":\"City view\",\"style\":\"light\"},\"status\":\"published\",\"featured\":false,\"short\":\"More space, more light and a window onto the city. Made for business trips that deserve a better night.\",\"tagline\":\"Space to work, room to unwind\",\"description\":\"More space and more light than our Deluxe, with a tall window onto the city. A work corner keeps the laptop close, the king bed keeps the night long. Made for business trips that deserve a better sleep.\",\"notes\":\"Check-in from 2:00 PM, check-out by 11:00 AM. Extra bed on request, subject to availability. Breakfast, Wi-Fi, parking and pool access are included.\",\"size\":38,\"guests\":2,\"bed\":\"King bed\",\"view\":\"City view\",\"inventory\":8,\"extraBed\":{\"available\":false,\"price\":0},\"price\":5800,\"seasonal\":{\"festive\":null,\"winter\":null,\"summer\":null,\"monsoon\":null},\"image\":\"assets/images/unicon/rooms/executive.jpg\",\"imageAlt\":\"Executive Room at Unicorn Hospitality\",\"gallery\":[],\"amenities\":[{\"icon\":\"wifi\",\"label\":\"Free Wi-Fi\"},{\"icon\":\"desk\",\"label\":\"Work corner\"},{\"icon\":\"snow\",\"label\":\"Air-conditioning\"},{\"icon\":\"tv\",\"label\":\"Flat-screen TV\"},{\"icon\":\"cup\",\"label\":\"Tea & coffee maker\"},{\"icon\":\"lock\",\"label\":\"In-room safe\"},{\"icon\":\"sun\",\"label\":\"City-view window\"},{\"icon\":\"car\",\"label\":\"Free parking\"}],\"features\":{\"desk\":true,\"shower\":false,\"lounge\":false,\"dining\":false,\"apart\":false},\"seoTitle\":\"\",\"seoDescription\":\"\",\"rank\":2,\"createdAt\":1793017963,\"updatedAt\":1793256466,\"updatedBy\":\"naman\"}',1793017963,1793256466);
INSERT INTO `rooms` VALUES ('family','Family Suite','suite','published',0,8200,52,4,3,'{\"id\":\"family\",\"name\":\"Family Suite\",\"category\":\"suite\",\"tags\":[\"family\"],\"badge\":{\"text\":\"Best for families\",\"style\":\"light\"},\"status\":\"published\",\"featured\":false,\"short\":\"Room for everyone: twin beds, a separate sleeping area and space to spread out after a long day out.\",\"tagline\":\"Everyone under one roof\",\"description\":\"Twin beds, a separate sleeping area and plenty of space to spread out after a long day. Wooden wardrobes, a bright bathroom and a calm, airy feel make it easy for the whole family to settle in.\",\"notes\":\"Check-in from 2:00 PM, check-out by 11:00 AM. Extra bed on request, subject to availability. Breakfast, Wi-Fi, parking and pool access are included.\",\"size\":52,\"guests\":4,\"bed\":\"2 twin beds\",\"view\":\"Garden side\",\"inventory\":4,\"extraBed\":{\"available\":true,\"price\":1200},\"price\":8200,\"seasonal\":{\"festive\":null,\"winter\":null,\"summer\":null,\"monsoon\":null},\"image\":\"assets/images/unicon/rooms/family.jpg\",\"imageAlt\":\"Family Suite at Unicorn Hospitality\",\"gallery\":[],\"amenities\":[{\"icon\":\"bed\",\"label\":\"Twin beds\"},{\"icon\":\"sofa\",\"label\":\"Extra sleeping space\"},{\"icon\":\"wifi\",\"label\":\"Free Wi-Fi\"},{\"icon\":\"snow\",\"label\":\"Air-conditioning\"},{\"icon\":\"tv\",\"label\":\"Flat-screen TV\"},{\"icon\":\"cup\",\"label\":\"Tea & coffee maker\"},{\"icon\":\"lock\",\"label\":\"In-room safe\"},{\"icon\":\"bath\",\"label\":\"Bathroom with shower\"}],\"features\":{\"desk\":false,\"shower\":false,\"lounge\":true,\"dining\":false,\"apart\":true},\"seoTitle\":\"\",\"seoDescription\":\"\",\"rank\":3,\"createdAt\":1793017963,\"updatedAt\":1793018005,\"updatedBy\":\"naman\"}',1793017963,1793018005);
INSERT INTO `rooms` VALUES ('premium','Premium Suite','suite','published',0,9800,60,3,4,'{\"id\":\"premium\",\"name\":\"Premium Suite\",\"category\":\"suite\",\"tags\":[],\"badge\":{\"text\":\"Warm & glowing\",\"style\":\"light\"},\"status\":\"published\",\"featured\":false,\"short\":\"Layered lighting, a statement headboard wall and a table for a quiet dinner in. Rich, warm and private.\",\"tagline\":\"Rich, warm and private\",\"description\":\"Layered lighting, a statement headboard wall and a small table for a quiet dinner in. The Premium Suite is warm, glowing and generously sized, for guests who like their evenings unhurried.\",\"notes\":\"Check-in from 2:00 PM, check-out by 11:00 AM. Extra bed on request, subject to availability. Breakfast, Wi-Fi, parking and pool access are included.\",\"size\":60,\"guests\":3,\"bed\":\"King bed\",\"view\":\"Courtyard\",\"inventory\":3,\"extraBed\":{\"available\":false,\"price\":0},\"price\":9800,\"seasonal\":{\"festive\":null,\"winter\":null,\"summer\":null,\"monsoon\":null},\"image\":\"assets/images/unicon/rooms/premium.jpg\",\"imageAlt\":\"Premium Suite at Unicorn Hospitality\",\"gallery\":[],\"amenities\":[{\"icon\":\"tv\",\"label\":\"Smart TV\"},{\"icon\":\"sofa\",\"label\":\"Dining nook\"},{\"icon\":\"drop\",\"label\":\"Rain shower\"},{\"icon\":\"wifi\",\"label\":\"Free Wi-Fi\"},{\"icon\":\"desk\",\"label\":\"Work desk\"},{\"icon\":\"snow\",\"label\":\"Air-conditioning\"},{\"icon\":\"lock\",\"label\":\"In-room safe\"},{\"icon\":\"cup\",\"label\":\"Tea & coffee maker\"}],\"features\":{\"desk\":true,\"shower\":true,\"lounge\":true,\"dining\":true,\"apart\":false},\"seoTitle\":\"\",\"seoDescription\":\"\",\"rank\":4,\"createdAt\":1793017963,\"updatedAt\":1793018007,\"updatedBy\":\"naman\"}',1793017963,1793018007);
INSERT INTO `rooms` VALUES ('unicon','The Unicon Suite','suite','published',1,14500,85,4,5,'{\"id\":\"unicon\",\"name\":\"The Unicon Suite\",\"category\":\"suite\",\"tags\":[\"family\",\"signature\"],\"badge\":{\"text\":\"Signature\",\"style\":\"gold\"},\"status\":\"published\",\"featured\":true,\"short\":\"Our most open, light-filled suite. Wide glass doors, natural timber and airy linen, made for slow mornings.\",\"tagline\":\"Our signature suite\",\"description\":\"Our most open, light-filled suite. Wide glass doors, natural timber and airy linen make mornings feel slow in the best way. A private lounge, a king bed and the most space we offer, all in one calm room.\",\"notes\":\"Check-in from 2:00 PM, check-out by 11:00 AM. Extra bed on request, subject to availability. Breakfast, Wi-Fi, parking and pool access are included.\",\"size\":85,\"guests\":4,\"bed\":\"King bed + lounge\",\"view\":\"Open view\",\"inventory\":1,\"extraBed\":{\"available\":false,\"price\":0},\"price\":14500,\"seasonal\":{\"festive\":null,\"winter\":null,\"summer\":null,\"monsoon\":null},\"image\":\"assets/images/unicon/rooms/unicon.webp\",\"imageAlt\":\"The Unicon Suite at Unicorn Hospitality\",\"gallery\":[],\"amenities\":[{\"icon\":\"sun\",\"label\":\"Open view\"},{\"icon\":\"sofa\",\"label\":\"Private lounge\"},{\"icon\":\"drop\",\"label\":\"Rain shower\"},{\"icon\":\"wifi\",\"label\":\"Free Wi-Fi\"},{\"icon\":\"desk\",\"label\":\"Work desk\"},{\"icon\":\"tv\",\"label\":\"Smart TV\"},{\"icon\":\"snow\",\"label\":\"Air-conditioning\"},{\"icon\":\"lock\",\"label\":\"In-room safe\"}],\"features\":{\"desk\":true,\"shower\":true,\"lounge\":true,\"dining\":true,\"apart\":true},\"seoTitle\":\"\",\"seoDescription\":\"\",\"rank\":5,\"createdAt\":1793017963,\"updatedAt\":1793018008,\"updatedBy\":\"naman\"}',1793017963,1793018008);
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_meta`
--

DROP TABLE IF EXISTS `site_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_meta` (
  `k` varchar(40) NOT NULL,
  `v` varchar(255) NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_meta`
--

LOCK TABLES `site_meta` WRITE;
/*!40000 ALTER TABLE `site_meta` DISABLE KEYS */;
INSERT INTO `site_meta` VALUES ('installed','1793080128');
INSERT INTO `site_meta` VALUES ('rooms_saved','1');
INSERT INTO `site_meta` VALUES ('rooms_updated','1793256470');
/*!40000 ALTER TABLE `site_meta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-09 15:25:28
